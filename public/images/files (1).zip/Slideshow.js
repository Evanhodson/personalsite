'use client'

// # SLIDESHOW
// Add your real images to /public/images/ and update the slides array.
// Images should be roughly 800×600px or similar landscape ratio.

import { useState } from 'react'

// ── UPDATE THESE with your own images + captions ──
const slides = [
  { emoji: '🏔', caption: 'Description of picture — a little context about this moment.' },
  { emoji: '🌊', caption: 'Another memory — add your caption here.'                      },
  { emoji: '🌿', caption: 'And another — keep them short and honest.'                    },
]
// When you have real images, replace emoji with:
// { src: '/images/your-photo.jpg', alt: 'Alt text', caption: '...' }

export default function Slideshow() {
  const [current, setCurrent] = useState(0)

  const prev = () => setCurrent(i => (i - 1 + slides.length) % slides.length)
  const next = () => setCurrent(i => (i + 1) % slides.length)

  return (
    <div className="slideshow-wrap">
      <p className="slide-eyebrow">Some things I&apos;ve done</p>

      <div className="slide-box">
        <button className="slide-arr" onClick={prev} aria-label="Previous">‹</button>
        <div className="slide-img-wrap">
          <div className="slide-placeholder">
            <span>{slides[current].emoji}</span>
          </div>
        </div>
        <button className="slide-arr" onClick={next} aria-label="Next">›</button>
      </div>

      <div className="slide-dots">
        {slides.map((_, i) => (
          <button
            key={i}
            className={`slide-dot${i === current ? ' active' : ''}`}
            onClick={() => setCurrent(i)}
            aria-label={`Slide ${i + 1}`}
          />
        ))}
      </div>

      <p className="slide-caption">{slides[current].caption}</p>
    </div>
  )
}
