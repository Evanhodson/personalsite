// # HOMEPAGE

import Nav from '../components/Nav'
import Slideshow from '../components/Slideshow'
import Contact from '../components/Contact'

// ── Creative section data — update titles as you publish ──
const blogs = ['Title placeholder one', 'Title placeholder two', 'Title placeholder three']
const vlogs = ['Title placeholder one', 'Title placeholder two', 'Title placeholder three']
const other = ['Title placeholder one', 'Title placeholder two', 'Title placeholder three']

export default function Home() {
  return (
    <>
      <Nav />


      {/* ── HERO ── */}
      <section className="hero">

        {/* Left: name + currently */}
        <div className="hero-left">
          <h1 className="hero-intro">
            Hey… I&apos;m <em>Evan.</em>
            <br />I do things.
          </h1>

          {/* Currently — sentence style, values in accent colour */}
          <div className="currently">
            <p className="cur-line">
              Where I am. <span>Vancouver</span>
            </p>
            <p className="cur-line">
              What I&apos;m doing. <span>Building things that matter</span>
            </p>
            <p className="cur-line">
              What I&apos;m reading. <span>The Making of a Manager</span>
            </p>
          </div>
        </div>

        {/* Right: slideshow */}
        <div className="hero-right">
          <Slideshow />
        </div>

      </section>


      {/* ── WHO I AM ── */}
      <section className="who">
        <h2 className="who-label">Who I am</h2>
        <p className="who-body">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
          quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.
          Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore
          eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
          sunt in culpa qui officia deserunt mollit anim id est laborum.
        </p>
        <p className="who-made">
          <a href="#creative">Who made me who I am?</a>
        </p>
      </section>


      {/* ── CREATIVE ── */}
      <section className="creative" id="creative">
        <p className="creative-label">Creative</p>

        <div className="creative-cols">

          {/* Blogs */}
          <div className="col">
            <h3 className="col-head warm">Blogs</h3>
            <p className="col-sub">I write my thoughts sometimes</p>
            <div className="col-divider" />
            {blogs.map(t => <a key={t} href="#" className="col-item">{t}</a>)}
            <p className="col-more">…</p>
          </div>

          {/* Vlogs */}
          <div className="col">
            <h3 className="col-head cool">Vlogs</h3>
            <p className="col-sub">I capture a few memories</p>
            <div className="col-divider" />
            {vlogs.map(t => <a key={t} href="#" className="col-item">{t}</a>)}
            <p className="col-more">…</p>
          </div>

          {/* Other */}
          <div className="col">
            <h3 className="col-head green">Other</h3>
            <p className="col-sub">I do other things occasionally</p>
            <div className="col-divider" />
            {other.map(t => <a key={t} href="#" className="col-item">{t}</a>)}
            <p className="col-more">…</p>
          </div>

        </div>
      </section>


      <Contact />
    </>
  )
}
